/* GAP – comportamiento de la web. Sin dependencias. */
(function () {
  'use strict';

  /* Menú móvil */
  var burger = document.querySelector('.burger');
  var mobileNav = document.getElementById('menu-movil');
  if (burger && mobileNav) {
    burger.addEventListener('click', function () {
      var abierto = mobileNav.classList.toggle('abierto');
      burger.setAttribute('aria-expanded', abierto ? 'true' : 'false');
      burger.setAttribute('aria-label', abierto ? 'Cerrar menú' : 'Abrir menú');
    });
    window.addEventListener('resize', function () {
      if (window.innerWidth > 1000) {
        mobileNav.classList.remove('abierto');
        burger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* Aparición al hacer scroll */
  var reveals = document.querySelectorAll('[data-reveal]');
  if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) {
    Array.prototype.forEach.call(reveals, function (el) { el.classList.add('visto'); });
  } else {
    var io = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (e) {
        /* isIntersecting no basta: un salto de scroll (ancla, tecla Fin, recarga
           con posición restaurada) deja atrás elementos que nunca intersecan.
           Lo que ya quedó por encima cuenta como visto. */
        if (e.isIntersecting || e.boundingClientRect.top < 0) {
          e.target.classList.add('visto');
          io.unobserve(e.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    Array.prototype.forEach.call(reveals, function (el) {
      /* Barrido inicial: lo que ya está por encima del viewport se muestra sin animar. */
      if (el.getBoundingClientRect().bottom < 0) { el.classList.add('visto'); return; }
      io.observe(el);
    });

    /* Respaldo: si la página se pintó oculta (abierta desde archivo local, pestaña
       en segundo plano, fuentes lentas), IntersectionObserver puede no disparar.
       Barremos lo que ya está dentro del viewport unas cuantas veces. */
    var barrer = function () {
      var alto = window.innerHeight || 800;
      Array.prototype.forEach.call(document.querySelectorAll('[data-reveal]:not(.visto)'), function (el) {
        if (el.getBoundingClientRect().top < alto * 0.92) { el.classList.add('visto'); io.unobserve(el); }
      });
    };
    barrer();
    window.addEventListener('load', barrer);
    setTimeout(barrer, 250);
    setTimeout(barrer, 900);
  }

  /* Año del pie */
  var anio = document.querySelector('[data-anio]');
  if (anio) { anio.textContent = new Date().getFullYear(); }

  /*
    Formularios. De momento solo muestran el panel de confirmación.
    Para producción: sustituye este bloque por un envío real
    (fetch a tu endpoint, Formspree, WPForms, Contact Form 7, etc.).
  */
  Array.prototype.forEach.call(document.querySelectorAll('form[data-form]'), function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var ok = document.getElementById(form.getAttribute('data-form') + '-ok');
      if (ok) { form.hidden = true; ok.hidden = false; ok.setAttribute('tabindex', '-1'); ok.focus(); }
    });
  });
})();
